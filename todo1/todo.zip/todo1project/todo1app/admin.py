from django.contrib import admin
from . models import Tas

# Register your models here.
admin.site.register(Tas)